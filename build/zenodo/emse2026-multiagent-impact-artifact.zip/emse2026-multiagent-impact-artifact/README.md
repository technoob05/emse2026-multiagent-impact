# Participation Is Not Collaboration

Reproducible artifact for an independent EMSE 2026 Special Issue draft based on AIDev-7.6M.

## Research questions

1. **Is there a handoff?** After review de-batching and rapid-burst collapse, how much cross-product activity forms a sequential public edge, and who takes the next visible step?
2. **Who bridges the boundary?** How visible is follow-up across a product boundary, and do first user-account mediators carry earlier public review history from the repository?
3. **Who writes the connection, and does the change get merged later?** Are an exact addressed edge and an automation-to-user relay linked to later merge after a fixed landmark, and is the edge written by another product or by a person?
4. **What goes with a review point being answered across the boundary?** Does an issue link in the pull request body change whether a review point gets answered, and does that depend on whether the reviewer is a different product?

## Main insight

Two products on one PR show participation, not collaboration. A visible handoff needs an addressed edge, a next owner, and an observable later state.

- A mapped product different from the triggering reviewer replies to the exact trigger on 74 PRs, below 1% of the complete trigger cohort.
- Excluding a five-minute rapid burst reduces mapped-product first ownership by 29%; user accounts own 53% of the first actions that remain.
- Cross-product triggers receive 13.4 percentage points less visible follow-up than same-product triggers matched on repository, PR-author account, author product, source, and month.
- 71% of first user-account mediators had reviewed a different PR in the same repository before the trigger.
- An exact reply to the trigger is associated with 17.3 points more later merge after measured pre-trigger controls. The association remains positive when the comparison is limited to PRs that already have other public discussion.
- That association has an E-value of 2.27 and a within-repository randomisation p of 0.007, and it stays positive under stricter edge definitions.
- The edge is written by a user account in 105 of 128 exposure events, by the triggering product replying to itself in 13, and by a different mapped product in 3. RQ3 therefore measures human acknowledgement, not agent-to-agent dialogue.
- The outcome cohort is the 27% of cross-product inline triggers still open at hour 48. Most such PRs close, and 64% merge, before the outcome window opens.
- Automation followed by a user account gives a secondary, same-direction check. Neither later-state contrast is a causal effect or a semantic resolution rate.

The paper does not claim semantic repair, verified manual work, private coordination, or a product ranking.

## Data

- Dataset: `hao-li/AIDev-7.6M`
- Revision: `37bbe1533e26cc1e1374917dba1186d1c8a4dc81`
- Default path: `../Legacy/AI_Dev_Dataminning/AIDev-7.6M`
- Full corpus: 7,685,281 PRs
- Rich AIDev-pop layer: 361,296 PRs
- PR creation cutoff: 31 March 2026
- Conservative interaction boundary: 15 April 2026

See `docs/guides/DATASET_GUIDE.md` for conceptual tables, joins, feature groups, and coverage.

### External evidence audit

Related public datasets were screened against the same event contract rather than pooled by row count. The frozen audit covers 15 candidates and 11 local acquisitions. The complete SWE-Review-Chat release was scanned, but all seven exact-edge candidates overlap the AIDev backbone, so no independent outcome cohort remains. The independently packaged AI-to-AI review cohort supports product-attribution and timing checks on overlapping PRs only. SWE-PRBench and AIReviewAction support semantic codebook checks, not reply-topology replication. See `docs/audits/CROSS_DATASET_COMPATIBILITY_20260826.md` and `docs/audits/EXTERNAL_DATA_PROVENANCE_20260826.md`.

## Reproduce the headline analysis

```powershell
uv sync
.\.venv\Scripts\python.exe scripts\analysis\run_cross_agent_review_exploration.py
.\.venv\Scripts\python.exe scripts\analysis\run_response_ownership_analysis.py
.\.venv\Scripts\python.exe scripts\analysis\run_response_ownership_robustness.py
.\.venv\Scripts\python.exe scripts\analysis\run_coordination_topology_analysis.py
.\.venv\Scripts\python.exe scripts\analysis\run_burst_collapsed_topology.py
.\.venv\Scripts\python.exe scripts\analysis\run_deep_coordination_transitions.py
.\.venv\Scripts\python.exe scripts\analysis\run_legacy_extension_ownership_persistence.py
.\.venv\Scripts\python.exe scripts\analysis\run_human_memory_bridge_analysis.py
.\.venv\Scripts\python.exe scripts\analysis\run_addressed_edge_landmark_analysis.py
.\.venv\Scripts\python.exe scripts\analysis\run_addressed_edge_specificity_analysis.py
.\.venv\Scripts\python.exe scripts\analysis\run_addressed_edge_confounding_sensitivity.py
.\.venv\Scripts\python.exe scripts\analysis\run_addressed_edge_scope_audit.py
.\.venv\Scripts\python.exe scripts\analysis\run_rq3_extensions.py
.\.venv\Scripts\python.exe scripts\analysis\run_rq3_landmark_selection_probe.py
.\.venv\Scripts\python.exe scripts\analysis\run_task_context_interaction.py
.\.venv\Scripts\python.exe scripts\analysis\run_merge_curves.py
.\.venv\Scripts\python.exe scripts\analysis\run_anchorability_coverage.py
.\.venv\Scripts\python.exe scripts\analysis\run_burst_threshold_selection.py
.\.venv\Scripts\python.exe scripts\analysis\run_constant_sensitivity_sweeps.py
.\.venv\Scripts\python.exe scripts\analysis\run_pseudo_edge_negative_control.py
.\.venv\Scripts\python.exe scripts\analysis\run_user_account_automation_audit.py
.\.venv\Scripts\python.exe scripts\analysis\run_addressed_edge_reply_content_audit.py
.\.venv\Scripts\python.exe scripts\analysis\run_heterogeneity_audit.py
.\.venv\Scripts\python.exe scripts\analysis\run_worked_example.py
.\.venv\Scripts\python.exe scripts\analysis\run_confounder_benchmarks.py
.\.venv\Scripts\python.exe scripts\analysis\run_matched_thread_position_audit.py
.\.venv\Scripts\python.exe scripts\analysis\run_swe_review_chat_exact_edge_pilot.py
.\.venv\Scripts\python.exe scripts\analysis\run_cross_corpus_attribution_sensitivity.py
.\.venv\Scripts\python.exe scripts\analysis\run_external_actionability_transfer_probe.py
.\.venv\Scripts\python.exe scripts\audit\prepare_review_collision_audit.py
.\.venv\Scripts\python.exe scripts\analysis\run_collision_descriptive_extension.py
.\.venv\Scripts\python.exe scripts\analysis\run_sample_flow.py
.\.venv\Scripts\python.exe scripts\reporting\generate_technical_appendix_tables.py
.\.venv\Scripts\python.exe scripts\validation\validate_response_ownership_outputs.py
.\.venv\Scripts\python.exe scripts\validation\validate_coordination_extension_outputs.py
.\.venv\Scripts\python.exe scripts\figures\visualize_manuscript_figures.py
uv run --with pytest python -m pytest -q
```

Three of those steps read third-party corpora rather than AIDev:
`run_swe_review_chat_exact_edge_pilot.py`,
`run_cross_corpus_attribution_sensitivity.py`, and
`run_external_actionability_transfer_probe.py` all need the acquisitions under
`external_data/`, which are not redistributed here. Their frozen products are
shipped, and the appendix's reproduction contract and disposition ledger read
them, so run them only if you have reacquired the sources listed in
`docs/audits/EXTERNAL_DATA_PROVENANCE_20260826.md`.

Build the figures, paper PDF, and flat source bundle:

```powershell
.\scripts\build_submission.ps1
```

## Key outputs

- `outputs/coordination_topology/`: exact-edge funnel, exact-author match, route controls, and robustness.
- `outputs/burst_topology/`: 0 to 30 minute burst sensitivity and leave-one-out checks.
- `outputs/deep_coordination/`: post-burst next-state transitions and product-composition placebo.
- `outputs/ownership_persistence/`: exact-owner/layer persistence and bidirectional bounce falsification.
- `outputs/human_memory_bridge/`: strict earlier-review history, decisive-review check, and leakage validation.
- `outputs/addressed_edge_landmark/`: exact-parent edge landmark models and robustness.
- `outputs/addressed_edge_specificity/`: exact edge versus generic public-discussion controls.
- `outputs/addressed_edge_sensitivity/`: E-values, unmeasured-confounder tipping grid, negative-control outcomes, and repository-stratified randomisation inference.
- `outputs/task_context_interaction/`: RQ4, whether an issue link in the PR body changes who answers a review point, split by whether the reviewer is a different product.
- `outputs/rq3_extensions/`: whole-population time-varying edge model, and the edge split by who wrote the reply with its repository fixed-effect check.
- `outputs/rq3_landmark_selection/`: whether the hour-48 landmark is itself post-exposure — an ordered selection probe, landmark-free whole-population estimates, and a sequential-landmark design where the cohort gate closes before the exposure window opens.
- `outputs/addressed_edge_scope/`: who writes the addressed edge, the estimate under stricter edge definitions, what the hour-48 landmark excludes, and the conditional within-repository randomisation test.
- `outputs/constant_sensitivity/`: sweeps of the load-bearing constants — the hour-48 landmark, the 30-day outcome horizon, the seven-day RQ1 follow-up window, and the bootstrap-draw count behind the Figure 4 bands.
- `outputs/external_validation/`: aggregate cross-dataset attribution, overlap, topology, and semantic-artifact audits.
- `outputs/review_collision/`: frozen 167-locus blinded dual-coder packet; semantic claims remain pending.
- `build/figures/Fig1_v2.pdf`: measurement contract, exclusion rules, and evidence levels.
- `build/figures/Fig2_v2.pdf`: RQ1 participation-to-edge and post-burst ownership figure.
- `build/figures/Fig3_v2.pdf`: RQ2 boundary visibility and prior-history figure.
- `build/figures/Fig4_v2.pdf`: RQ3 cumulative-merge curves for on-target, off-target, and no-reply pull requests — the anchoring placebo, showing the two replied groups' intervals overlap everywhere.
- `build/figures/Fig5_v2.pdf`: RQ3 E-value tipping grid — how prevalent and how strong an unmeasured factor would have to be, with the four strongest measured factors plotted for scale. No placebo outcomes appear in this figure.
- `build/figures/Fig6_v2.pdf`: RQ4 issue-link figure — answer rates within and across the product boundary, and the raw contrast beside its within-repository, within-month estimate.
- `outputs/figures/dataset_schema_and_joins.pdf`: appendix map of both release layers and identifier joins.
- `outputs/figures/dataset_feature_coverage.pdf`: appendix view of feature availability and valid denominators.
- `paper/manuscript/main.tex`: EMSE manuscript source.
- `paper/manuscript/technical_appendix.tex`: full supplementary methods, estimates, falsification tests, and decision ledger.
- `paper/manuscript/main.pdf`: the compiled article, 37 pages.
- `paper/manuscript/technical_appendix.pdf`: the compiled Online Resource 1, 37 pages.
- `paper/SUBMISSION_METADATA_FORM.md`: author-approved metadata and declaration intake form.

Anything under `build/` is scratch output from an older packaging step and is
**not** the upload bundle. As of the last check `build/pdf/` still held a 22-page
manuscript and a 46-page appendix from an earlier draft. Do not upload from it.

## What to upload

`SUBMIT/` is the upload bundle, and the only one. It is regenerated by

```powershell
.\.venv\Scripts\python.exe scripts\release\build_submit_folder.py
```

which refuses to run if a PDF is older than a source file it is built from, so it
cannot quietly ship an old draft. It contains the article PDF, `ESM_1.pdf` for
Online Resource 1, the flat LaTeX source archive for the article, the cover
letter, the metadata form, the two checklists, and `CHECKSUMS.sha256`. Verify the
bundle before uploading:

```powershell
cd SUBMIT; sha256sum -c CHECKSUMS.sha256
```

`SUBMIT/README.md` says which file goes into which Editorial Manager field.

## Superseded material

The `outputs/` tree also holds results from an earlier version of this study,
including files that reuse the names RQ1, RQ2, and RQ3 for different questions.
None of it feeds the paper. See `outputs/_superseded/README.md` for the list.
Neither that tree nor the internal design notes under `docs/notes/` and
`docs/decisions/` are part of the published artifact; they are working records
of this repository, and several of them are superseded by the manuscript.

## Submission gates

Affiliations, corresponding email, declarations, ethics and consent wording, the five ORCIDs and the artifact DOI (`10.5281/zenodo.22140821`) are all filled in. Two things still need a person: the submission date, and publishing the Zenodo draft, which is irreversible. The official Editorial Manager page displayed a temporary “site under development” warning and must be rechecked before upload. Semantic coding is required only if the authors later add duplication, complementarity, or contradiction claims; the present paper does not make them. See `paper/SUBMISSION_READINESS.md`.
